**To delete a custom domain name**

Command::

  aws apigateway delete-domain-name --domain-name 'api.domain.tld'
