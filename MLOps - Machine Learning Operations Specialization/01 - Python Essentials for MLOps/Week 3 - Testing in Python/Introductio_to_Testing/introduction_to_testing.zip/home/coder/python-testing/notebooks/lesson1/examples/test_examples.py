

def test_passes():
    assert True

def test_fails():
    assert False
